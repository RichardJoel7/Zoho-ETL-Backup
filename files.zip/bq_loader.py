"""
bq_loader.py — Production-grade BigQuery loader.

Key differences from the legacy utils.py:
  - MERGE (upsert) instead of WRITE_TRUNCATE — no data loss on partial failure
  - Schema auto-detection with safe type coercion
  - Dataset existence check (idempotent)
  - Batch inserts with configurable chunk size
  - Row-count validation after every load
  - Structured load logs written to pipeline_metadata.load_log
"""

import json
import logging
import os
import tempfile
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional

from google.cloud import bigquery
from google.oauth2 import service_account
from google.api_core.exceptions import NotFound

from config.settings import BQ_META_DATASET, BQ_BATCH_SIZE

logger = logging.getLogger(__name__)

LOAD_LOG_TABLE = "load_log"


# ---------------------------------------------------------------------------
# Client factory
# ---------------------------------------------------------------------------
def get_bq_client(credentials_json: Optional[str] = None) -> bigquery.Client:
    """
    Returns an authenticated BigQuery client.
    Prefers credentials_json string (GitHub Secret) over ADC for CI/CD compatibility.
    Falls back to Application Default Credentials for local dev.
    """
    project_id = os.getenv("GCP_PROJECT_ID", "")

    if credentials_json:
        try:
            creds_dict = json.loads(credentials_json)
            credentials = service_account.Credentials.from_service_account_info(
                creds_dict,
                scopes=["https://www.googleapis.com/auth/cloud-platform"],
            )
            return bigquery.Client(project=project_id, credentials=credentials)
        except (json.JSONDecodeError, ValueError) as e:
            raise ValueError(f"Invalid GCP_CREDENTIALS_JSON: {e}") from e

    # Local development — uses `gcloud auth application-default login`
    logger.info("No credentials JSON provided — using Application Default Credentials.")
    return bigquery.Client(project=project_id)


# ---------------------------------------------------------------------------
# Dataset management
# ---------------------------------------------------------------------------
def ensure_dataset_exists(client: bigquery.Client, dataset_id: str) -> None:
    """Creates the dataset if it doesn't exist. Idempotent."""
    dataset_ref = bigquery.Dataset(f"{client.project}.{dataset_id}")
    dataset_ref.location = "US"
    try:
        client.get_dataset(dataset_ref)
    except NotFound:
        client.create_dataset(dataset_ref, exists_ok=True)
        logger.info(f"Created BigQuery dataset: {dataset_id}")


# ---------------------------------------------------------------------------
# Schema inference
# ---------------------------------------------------------------------------
def _infer_schema(records: List[Dict]) -> List[bigquery.SchemaField]:
    """
    Infers a BigQuery schema from a list of dicts.
    Samples the first 100 rows for type detection.
    All unknown/mixed types default to STRING (safe fallback).
    """
    type_map: Dict[str, str] = {}
    sample = records[:100]

    for row in sample:
        for key, value in row.items():
            if value is None:
                continue
            col = key.replace("-", "_").replace(".", "_").replace(" ", "_")
            detected = _detect_type(value)
            existing = type_map.get(col)
            if existing is None:
                type_map[col] = detected
            elif existing != detected:
                type_map[col] = "STRING"  # Type conflict → fallback to STRING

    # Any key not sampled (all-null column) → STRING
    all_keys = {
        k.replace("-", "_").replace(".", "_").replace(" ", "_")
        for row in records
        for k in row.keys()
    }
    for col in all_keys:
        if col not in type_map:
            type_map[col] = "STRING"

    return [
        bigquery.SchemaField(col, bq_type, mode="NULLABLE")
        for col, bq_type in sorted(type_map.items())
    ]


def _detect_type(value: Any) -> str:
    if isinstance(value, bool):
        return "BOOLEAN"
    if isinstance(value, int):
        return "INTEGER"
    if isinstance(value, float):
        return "FLOAT"
    if isinstance(value, dict):
        return "STRING"  # Serialize nested dicts as JSON strings
    if isinstance(value, list):
        return "STRING"  # Serialize lists as JSON strings
    return "STRING"


# ---------------------------------------------------------------------------
# Row normalisation
# ---------------------------------------------------------------------------
def _normalise_row(row: Dict) -> Dict:
    """
    Coerces values to BQ-safe types and sanitises column names.
    - Dicts and lists → JSON strings
    - Column names: replace special chars with underscore
    - Strip None values from keys with None to avoid BQ insert errors
    """
    clean = {}
    for k, v in row.items():
        safe_key = k.replace("-", "_").replace(".", "_").replace(" ", "_")
        if isinstance(v, (dict, list)):
            clean[safe_key] = json.dumps(v, default=str)
        elif isinstance(v, bool):
            clean[safe_key] = v
        elif v is None:
            clean[safe_key] = None
        else:
            clean[safe_key] = str(v) if not isinstance(v, (int, float)) else v
    return clean


# ---------------------------------------------------------------------------
# Staging load (for MERGE workflow)
# ---------------------------------------------------------------------------
def load_to_staging(
    client: bigquery.Client,
    dataset_id: str,
    records: List[Dict],
    staging_table: str,
) -> int:
    """
    Loads records into a staging table using WRITE_TRUNCATE.
    The staging table is always fully replaced — it's transient, used only
    for the subsequent MERGE. Returns row count loaded.
    """
    if not records:
        logger.info(f"No records to load into staging table {staging_table}.")
        return 0

    normalised = [_normalise_row(r) for r in records]
    schema = _infer_schema(normalised)
    table_id = f"{client.project}.{dataset_id}.{staging_table}"

    # Write via NDJSON file for large payloads (avoids streaming insert quotas)
    with tempfile.NamedTemporaryFile(mode="w", suffix=".ndjson", delete=False) as f:
        for row in normalised:
            f.write(json.dumps(row, default=str) + "\n")
        tmp_path = f.name

    job_config = bigquery.LoadJobConfig(
        schema=schema,
        source_format=bigquery.SourceFormat.NEWLINE_DELIMITED_JSON,
        write_disposition=bigquery.WriteDisposition.WRITE_TRUNCATE,
        ignore_unknown_values=True,
        max_bad_records=10,
    )

    try:
        with open(tmp_path, "rb") as f:
            load_job = client.load_table_from_file(f, table_id, job_config=job_config)
        load_job.result()

        table = client.get_table(table_id)
        loaded = table.num_rows
        logger.info(f"Staging load complete: {table_id} — {loaded} rows")
        return loaded
    except Exception as e:
        logger.error(f"Staging load failed for {table_id}: {e}")
        raise
    finally:
        os.unlink(tmp_path)


# ---------------------------------------------------------------------------
# MERGE — upsert staging → target
# ---------------------------------------------------------------------------
def merge_staging_to_target(
    client: bigquery.Client,
    dataset_id: str,
    staging_table: str,
    target_table: str,
    id_column: str = "id",
) -> int:
    """
    Performs a MERGE (upsert) from staging into the target table.
    - Matched rows → UPDATE all columns
    - Unmatched rows → INSERT
    Returns the number of rows in the target table after the merge.
    """
    staging_id = f"{client.project}.{dataset_id}.{staging_table}"
    target_id = f"{client.project}.{dataset_id}.{target_table}"

    # Get column list from staging table
    staging_schema = client.get_table(staging_id).schema
    columns = [field.name for field in staging_schema]

    if id_column not in columns:
        logger.warning(
            f"ID column '{id_column}' not found in staging schema. "
            f"Falling back to full WRITE_TRUNCATE for {target_table}."
        )
        _copy_staging_to_target(client, staging_id, target_id)
        return client.get_table(target_id).num_rows

    update_clauses = ", ".join(
        f"T.{c} = S.{c}" for c in columns if c != id_column
    )
    insert_cols = ", ".join(columns)
    insert_vals = ", ".join(f"S.{c}" for c in columns)

    # Ensure target table exists (first run)
    _ensure_target_table_exists(client, staging_id, target_id, staging_schema)

    merge_sql = f"""
        MERGE `{target_id}` AS T
        USING `{staging_id}` AS S
        ON T.{id_column} = S.{id_column}
        WHEN MATCHED THEN
            UPDATE SET {update_clauses}
        WHEN NOT MATCHED BY TARGET THEN
            INSERT ({insert_cols})
            VALUES ({insert_vals})
    """

    try:
        client.query(merge_sql).result()
        final_count = client.get_table(target_id).num_rows
        logger.info(f"MERGE complete: {target_id} — {final_count} total rows")
        return final_count
    except Exception as e:
        logger.error(f"MERGE failed for {target_id}: {e}")
        raise


def _ensure_target_table_exists(
    client: bigquery.Client,
    staging_id: str,
    target_id: str,
    schema: List[bigquery.SchemaField],
) -> None:
    """Creates the target table from the staging schema if it doesn't exist yet."""
    try:
        client.get_table(target_id)
    except NotFound:
        table = bigquery.Table(target_id, schema=schema)
        client.create_table(table)
        logger.info(f"Created target table: {target_id}")


def _copy_staging_to_target(
    client: bigquery.Client, staging_id: str, target_id: str
) -> None:
    """Full copy fallback when ID column is absent."""
    copy_sql = f"""
        CREATE OR REPLACE TABLE `{target_id}` AS
        SELECT * FROM `{staging_id}`
    """
    client.query(copy_sql).result()


# ---------------------------------------------------------------------------
# Data quality check
# ---------------------------------------------------------------------------
def validate_row_count(
    client: bigquery.Client,
    dataset_id: str,
    table_name: str,
    expected_min: int,
) -> bool:
    """
    Warns (does not fail) if actual row count is below expected_min.
    Returns True if healthy, False if suspicious.
    """
    table_id = f"{client.project}.{dataset_id}.{table_name}"
    try:
        actual = client.get_table(table_id).num_rows
        if actual < expected_min:
            logger.warning(
                f"DATA QUALITY WARNING: {table_name} has {actual} rows "
                f"but expected at least {expected_min}."
            )
            return False
        return True
    except Exception as e:
        logger.warning(f"Row count check failed for {table_name}: {e}")
        return False


# ---------------------------------------------------------------------------
# Execution log
# ---------------------------------------------------------------------------
def log_execution(
    client: bigquery.Client,
    source: str,
    start_time: datetime,
    status: str,
    records_processed: int,
    error_message: Optional[str] = None,
    api_calls: int = 0,
) -> None:
    """Writes a structured run record to pipeline_metadata.load_log."""
    ensure_dataset_exists(client, BQ_META_DATASET)
    table_id = f"{client.project}.{BQ_META_DATASET}.{LOAD_LOG_TABLE}"

    end_time = datetime.now(timezone.utc)
    duration_seconds = (end_time - start_time).total_seconds()

    row = {
        "source": source,
        "status": status,
        "records_processed": records_processed,
        "api_calls": api_calls,
        "duration_seconds": duration_seconds,
        "error_message": error_message or "",
        "started_at": start_time.isoformat(),
        "finished_at": end_time.isoformat(),
    }

    schema = [
        bigquery.SchemaField("source", "STRING"),
        bigquery.SchemaField("status", "STRING"),
        bigquery.SchemaField("records_processed", "INTEGER"),
        bigquery.SchemaField("api_calls", "INTEGER"),
        bigquery.SchemaField("duration_seconds", "FLOAT"),
        bigquery.SchemaField("error_message", "STRING"),
        bigquery.SchemaField("started_at", "TIMESTAMP"),
        bigquery.SchemaField("finished_at", "TIMESTAMP"),
    ]

    table = bigquery.Table(table_id, schema=schema)
    try:
        client.get_table(table_id)
    except NotFound:
        client.create_table(table)

    errors = client.insert_rows_json(table_id, [row])
    if errors:
        logger.warning(f"Failed to write load log: {errors}")
    else:
        logger.info(
            f"Run log written: source={source} status={status} "
            f"records={records_processed} duration={duration_seconds:.1f}s"
        )
